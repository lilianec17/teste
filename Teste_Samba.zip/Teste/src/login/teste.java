package login;

import static org.junit.Assert.assertTrue;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
//private static WebDriver driver; // Objeto Webdriver

public class teste{ // Cria uma instância do navegador e abre a tela de login.
	@BeforeClass // antes do teste
	public static void AbreFirefox(){
		WebDriver driver = new FirefoxDriver();
		driver.get("http://52.2.166.124:8085/");
	}
	
	// Método que finalize o teste, fechando a instância do WebDriver.    
	@AfterClass // antes do teste
	public static void FechaNavegador(){
		WebDriver driver = null;
		driver.quit(); // Fecha o browser, mesmo que existam diversas janelas abertas
	}
	
	// Método que testa que o login e senha válidos.
		@Test //  Junit saberá controla se um teste deve ser executado, sempre acima de um método público 
		public void testaLoginOKSenhaOK() {
			WebDriver driver = null;
            // Valida email 
			String email = "​avaliacao_qa_samba@sambatech.com.br";
			assertTrue(email.equals("​avaliacao_qa_samba@sambatech.com.br"));
            // Valida senha 
			String senha = "12345678";
			assertTrue(senha.equals("12345678"));
		    // Clica no botão "Entrar"
			driver.findElement(By.id("entrar")).click(); 
			// findElement-Encontra um único elemento, 
			//By.id-Localiza o elemento	pelo atributo id	 
		}
		
		// Método que testa que o login inválido e senha válida.
		@Test 
		public void testaLoginNOKSenhaOK() {
			WebDriver driver = null;
			 // Valida email 
			String email = "emailinvalido@sambatech.com.br";
			assertTrue("Email inválido.", email.equals("emailinvalido@sambatech.com.br"));
            // Valida senha 
			String senha = "12345678";
			assertTrue(senha.equals("12345678"));
		    // Clica no botão "Entrar"
			driver.findElement(By.id("entrar")).click(); 
			// findElement-Encontra um único elemento, 
			//By.id-Localiza o elemento	pelo atributo id	
		}
		// Método que testa que o login válido e senha inválida.
		@Test
		public void testaLoginOKSenhaNOK() {
			WebDriver driver = null;
			// Valida email 
			String email = "​avaliacao_qa_samba@sambatech.com.br";
			assertTrue(email.equals("​avaliacao_qa_samba@sambatech.com.br"));
			// Valida senha 
			String senha = "87654321";
			assertTrue("Senha inválida.", senha.equals("87654321"));
			// Clica no botão "Entrar"
			driver.findElement(By.id("entrar")).click(); 
			// findElement-Encontra um único elemento, 
			//By.id-Localiza o elemento	pelo atributo id	
		}
		// Método que testa que o login e senha estão inválidos.

		@Test 
		public void testaLoginNOKSenhaNOK() {
			WebDriver driver = null;
			// Valida email 
            String email = "emailinvalido@sambatech.com.br";
			assertTrue("Email e/ou senha inválidos.", email.equals("emailinvalido@sambatech.com.br"));
			// Valida senha 
		    String senha = "87654321";
			assertTrue("Email e/ou senha inválidos.", senha.equals("87654321"));
			// Clica no botão "Entrar"
			driver.findElement(By.id("entrar")).click(); 
			// findElement-Encontra um único elemento, 
			//By.id-Localiza o elemento	pelo atributo id	
			
			// Método que testa que o login e senha em branco.
		   }
			@Test 
			public void testaLoginBranco() {
				WebDriver driver = null;
				// Valida email 
	            String email = " ";
				assertTrue("Por favor informe seu Email e/ou senha.", email.equals("emailinvalido@sambatech.com.br"));
				// Valida senha 
			    String senha = " ";
				assertTrue("Por favor informe seu Email e/ou senha.", senha.equals("87654321"));
				// Clica no botão "Entrar"
				driver.findElement(By.id("entrar")).click(); 
				// findElement-Encontra um único elemento, 
				//By.id-Localiza o elemento	pelo atributo id	
			}
}//Fim teste